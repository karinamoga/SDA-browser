/*MOGA KARINA 311 CB*/
#ifndef STRUCTURI_H
#define STRUCTURI_H

#include <stdio.h>

// Pagina
typedef struct {
	int id;
	char url[150];
	char *description;
} TPage;

// stiva
typedef struct cell_stack {
	TPage *page;
	struct cell_stack *next;
} TCellStack, *TStack;

// Tab 
typedef struct {
	int id;
	TPage *current_page;
	TStack backward;
	TStack forward;
} TTab;

// Celula taburi (listă dublu înlănțuită circulara)
typedef struct list_cell {
	TTab *tab;
	struct list_cell *prev, *next;
} TCellTab, *TTabList;

// browser
typedef struct {
	TTab *current_tab;
	TTabList list; // lista circulara cu santinela
} TBrowser;



// Alocare
TPage* CreeazaPagina(int id, const char *url, const char *descriere);
TTab* CreeazaTab(int id, TPage *pagina);
TTabList CreeazaCelulaTab(TTab *tab);
TTabList InitListaTaburi();
TBrowser* InitBrowser();
void DistrugeStiva(TStack *vf);
void FreeTab(TTab *tab);
void PrintTabs(TBrowser *br, FILE *fout);
TPage* GasestePagina(TPage **pagini, int n, int id);
void FreeListaTaburi(TTabList lista);
void FreeBrowser(TBrowser *br);


// Taskuri
int NewTab(TBrowser *br, TPage *pagina);
int CloseTab(TBrowser *br, FILE *fout);
int OpenTab(TBrowser *br, int id, FILE *fout);
void NextTab(TBrowser *br);
void PrevTab(TBrowser *br);
void DeschidePagina(TBrowser *br, TPage *noua_pagina);
void Backward(TBrowser *br, FILE *fout);
void Forward(TBrowser *br, FILE *fout);
void PrintHistory(TBrowser *br, int id, FILE *fout);

#endif
